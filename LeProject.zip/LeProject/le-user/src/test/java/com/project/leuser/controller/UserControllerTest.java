package com.project.leuser.controller;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

/**
 * @author whl
 * @Description:
 * @date 2023/7/14
 */
class UserControllerTest {

    @Test
    void login() {
    }
}