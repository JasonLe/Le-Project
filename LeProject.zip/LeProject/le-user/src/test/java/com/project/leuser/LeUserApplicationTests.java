package com.project.leuser;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LeUserApplicationTests {

    @Test
    void contextLoads() {
    }

}
