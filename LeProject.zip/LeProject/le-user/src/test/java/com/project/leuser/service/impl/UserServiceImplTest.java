package com.project.leuser.service.impl;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

/**
 * @author whl
 * @Description:
 * @date 2023/7/14
 */
class UserServiceImplTest {

    @Test
    void login() {
    }
}