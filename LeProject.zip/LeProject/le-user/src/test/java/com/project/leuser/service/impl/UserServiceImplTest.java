package com.project.leuser.service.impl;

import com.auth0.jwt.JWT;
import com.auth0.jwt.JWTVerifier;
import com.auth0.jwt.algorithms.Algorithm;
import com.auth0.jwt.exceptions.JWTVerificationException;
import com.auth0.jwt.exceptions.TokenExpiredException;
import com.auth0.jwt.interfaces.DecodedJWT;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

/**
 * @author whl
 * @Description:
 * @date 2023/7/12
 */
@SpringBootTest
class UserServiceImplTest {

    @Test
    public void makeToken() {
        //1、日历类
        Calendar calendar = Calendar.getInstance();
        //2、设置时间为 1小时过期
        calendar.add(Calendar.MINUTE, 60);
        Map<String, Object> map = new HashMap<>();
        //3、生成令牌
        String token = JWT.create()
                .withHeader(map)//第一部分 头使用默认值   签名算法:HS256 type:jwt
                .withClaim("username", "rk")//第二部分
                .withClaim("age", 20)
                .withIssuedAt(new Date(System.currentTimeMillis()))//设置令牌发放时间
                .withExpiresAt(calendar.getTime())//设置过期时间
                .sign(Algorithm.HMAC256("LUOLIN!@$%#@"));//第三部分 设置签名，LUOLIN!@$%#@为秘钥
        //4、输出令牌
        System.out.println(token);
    }

    //解析token
    @Test
    public void parseToken(){
        try {
            String token="eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJleHAiOjE2ODkxNDgwMzgsImlhdCI6MTY4OTE0NDQzOCwiYWdlIjoyMCwidXNlcm5hbWUiOiJyayJ9.zl8AFZwNbRPTi6jAZdO9kBc42qsX0ZNMCh9aNIvN2eA";
            //1、创建验证对象
            JWTVerifier jwtVerifier = JWT.require(Algorithm.HMAC256("LUOLIN!@$%#@")).build();
            //2、校验签名(校验token是否合法)
            DecodedJWT jwt = jwtVerifier.verify(token);

            System.out.println("用户名:"+jwt.getClaim("username").asString());
            System.out.println("年龄:"+jwt.getClaim("age").asInt());
            SimpleDateFormat sdf=new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");
            System.out.println("令牌发放时间:"+sdf.format(jwt.getIssuedAt()));
            System.out.println("令牌过期时间:"+sdf.format(jwt.getExpiresAt()));
        }
        catch (TokenExpiredException e){
            System.out.println("token已过期!");
        }
        catch (JWTVerificationException e) {
            System.out.println("token不合法!");
        }
    }
}