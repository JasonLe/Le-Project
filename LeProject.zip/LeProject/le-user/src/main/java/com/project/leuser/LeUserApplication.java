package com.project.leuser;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LeUserApplication {

    public static void main(String[] args) {
        SpringApplication.run(LeUserApplication.class, args);
    }

}
