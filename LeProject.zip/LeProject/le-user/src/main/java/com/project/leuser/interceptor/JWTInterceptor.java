package com.project.leuser.interceptor;

import cn.hutool.core.util.StrUtil;
import com.auth0.jwt.exceptions.JWTDecodeException;
import com.auth0.jwt.exceptions.TokenExpiredException;
import com.project.lecommon.enums.ExceptionEnum;
import com.project.lecommon.exception.MyException;
import com.project.leuser.utils.JWTUtil;
import org.springframework.web.servlet.HandlerInterceptor;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * @author whl
 * @Description:
 * @date 2023/7/14
 */
public class JWTInterceptor implements HandlerInterceptor {

    private static final String LE_TOKEN = "Le-Token";

    @Override
    public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) {
        String token = request.getHeader(LE_TOKEN);
        if (StrUtil.isBlank(token)) {
            throw new MyException(ExceptionEnum.NO_LOGIN);
        }
        try {
            JWTUtil.verifyToken(token);
        } catch (TokenExpiredException e) {
            throw new MyException(ExceptionEnum.TOKEN_EXPIRED);
        } catch (JWTDecodeException e) {
            throw new MyException(ExceptionEnum.TOKEN_ERROR);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return true;
    }
}
