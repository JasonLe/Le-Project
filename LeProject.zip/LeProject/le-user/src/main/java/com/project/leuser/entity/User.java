package com.project.leuser.entity;

import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.Data;

import java.util.Date;

/**
 * @author whl
 * @Description:
 * @date 2023/7/12
 */
@Data
@TableName("user")
public class User {
    @TableId
    private String id;
    private String username;
    private String password;
    private String mobile;
    private String email;
    private String location;
    private Date createTime;
    private Date updateTime;
}
