package com.project.leuser.entity;

import lombok.Data;

import java.util.Date;

/**
 * @author whl
 * @Description:
 * @date 2023/7/12
 */
@Data
@TableName("user")
public class User {
    private String id;
    private String userName;
    private String passWord;
    private String mobile;
    private String location;
    private Date createTime;
    private Date modifyTime;
}
