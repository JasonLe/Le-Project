package com.project.leuser.mapper;

/**
 * @author whl
 * @Description:
 * @date 2023/7/12
 */
public class UserMapper extends BaseMapper{
}
