package com.project.leuser.service.impl;

import com.project.leuser.dto.LoginDTO;
import com.project.leuser.entity.User;
import com.project.leuser.service.UserService;
import com.project.leuser.utils.JWTUtil;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.Map;

/**
 * @author whl
 * @Description:
 * @date 2023/7/12
 */
@Slf4j
@Service
public class UserServiceImpl implements UserService {
    @Override
    public User login(LoginDTO loginDTO) {
        try{
            Map<String,String> params = new HashMap<String, String>();
            params.put("username",loginDTO.getUserName());
            params.put("passowrd",loginDTO.getPassWord());
            String token = JWTUtil.generateToken(params);

        }catch (Exception e){
            log.info(e.getMessage());
        }
        return null;
    }
}
