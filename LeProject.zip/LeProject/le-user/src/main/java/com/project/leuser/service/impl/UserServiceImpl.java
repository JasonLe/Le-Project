package com.project.leuser.service.impl;

import cn.hutool.core.bean.BeanUtil;
import cn.hutool.core.lang.Validator;
import cn.hutool.core.util.ObjectUtil;
import cn.hutool.crypto.digest.DigestUtil;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.project.lecommon.exception.MyException;
import com.project.leuser.dto.request.LoginDTO;
import com.project.leuser.dto.request.RegisterDTO;
import com.project.leuser.dto.response.TokenResponse;
import com.project.leuser.entity.User;
import com.project.leuser.mapper.UserMapper;
import com.project.leuser.service.UserService;
import com.project.leuser.utils.JWTUtil;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

/**
 * @author whl
 * @Description:
 * @date 2023/7/12
 */
@Slf4j
@Service
public class UserServiceImpl implements UserService {

    @Autowired
    private UserMapper userMapper;

    @Override
    public TokenResponse login(LoginDTO loginDTO) {

        Map<String, String> params = new HashMap<>(2);
        params.put("username", loginDTO.getUsername());
        params.put("password", loginDTO.getPassword());

        QueryWrapper<User> wrapper = new QueryWrapper<User>()
                .select()
                .allEq(params);
        User user = userMapper.selectOne(wrapper);
        if (ObjectUtil.isNull(user)) {
            throw new MyException("用户不存在");
        }
        String token = JWTUtil.generateToken(user);

        return TokenResponse.builder().leToken(token).user(user).build();
    }

    @Override
    public Boolean register(RegisterDTO registerDTO) {
        // 注册入参校验
        userVerification(registerDTO);

        User registerUser = new User();
        BeanUtil.copyProperties(registerDTO, registerUser);

        registerUser.setCreateTime(new Date());
        // 密码逻辑 email|password
        registerUser.setPassword(DigestUtil.md5Hex(registerUser.getEmail() + "|" + registerUser.getPassword()));
        // 临时输出密码
        log.info(registerUser.getPassword());
        int count = userMapper.insert(registerUser);
        return count == 1;
    }

    /**
     * 注册入参校验
     **/
    private void userVerification(RegisterDTO registerDTO) {
        if (!Validator.isMobile(registerDTO.getMobile())) {
            throw new MyException("手机号格式错误");
        }
        if (!Validator.isEmail(registerDTO.getEmail())) {
            throw new MyException("邮箱格式错误");
        }
    }

    @Override
    public User getUser(Integer id) {
        return userMapper.selectById(id);
    }
}
