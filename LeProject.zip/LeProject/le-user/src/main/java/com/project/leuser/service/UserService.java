package com.project.leuser.service;

import com.project.leuser.dto.LoginDTO;
import com.project.leuser.entity.User;

/**
 * @author whl
 * @Description:
 * @date 2023/7/12
 */
public interface UserService {
    /**
     * @author whl
     * @description 登录接口
     * @date 2023/7/12
     * @param loginDTO
     * @return User
     **/
    User login(LoginDTO loginDTO);
}
