package com.project.leuser.controller;

import com.project.leuser.dto.LoginDTO;
import com.project.leuser.entity.User;
import com.project.leuser.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * @author whl
 * @Description:
 * @date 2023/7/12
 */
@RestController
@RequestMapping("/le-user")
public class UserController {

    @Autowired
    private UserService userService;

    @PostMapping("/login")
    User login(LoginDTO loginDTO){
        return userService.login(loginDTO);
    }
}
